import React from 'react';

function LikeFolder(props) {
    return (
        <div>
            LikeFolderLikeFolderLikeFolderLikeFolderLikeFolder
        </div>
    );
}

export default LikeFolder;