import React from 'react';
import { SlackSelector } from 'react-reactions';

const Slack = () => {
  return (
    <SlackSelector />
  )
}

export default Slack;

